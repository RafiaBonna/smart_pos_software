<?php

    $servername = "localhost";

    $username = "rafiaakter1";

    $password = "rafiaakter607@";

    $dbname = "rafiabonna_create_db"; 

    $conn = new mysqli($servername, $username, $password, $dbname);

    if($conn->connect_error) {

        die("Connection Failed" . $conn->connect_error);

    }

?>